export const firebaseConfig = {
	apiKey: 'AIzaSyBHpbsjudMZrHP7p3E_0XiZzqckdtawrVU',
	authDomain: 'lab12-spotify.firebaseapp.com',
	projectId: 'lab12-spotify',
	storageBucket: 'lab12-spotify.appspot.com',
	messagingSenderId: '540821994375',
	appId: '1:540821994375:web:1f9e5304fb8024c8903122',
	measurementId: 'G-JTKBJ0EELW',
};
