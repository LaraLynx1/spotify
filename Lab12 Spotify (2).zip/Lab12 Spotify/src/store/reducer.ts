import { AppState } from '../types/store';

export const reducer = (currentAction: any, currentState: any): AppState => {
	return { something: {} };
};
