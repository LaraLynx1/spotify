export enum Coleccion {
	'PLAYLIST' = 'playlist',
}
