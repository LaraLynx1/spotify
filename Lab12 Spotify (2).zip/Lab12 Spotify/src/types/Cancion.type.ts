export type Cancion = {
	id: string;
	image: string;
	title: string;
	author: string;
	album: string;
	createdAt: string;
	duracion: string;
};
